#include <stdbool.h>

#define MAXNUMVERTICES 100
#define AN -1

typedef float Peso;

typedef struct {
    Peso mat [MAXNUMVERTICES+1][MAXNUMVERTICES+1];
    int numVertices;
    int numArestas;
}Grafo;

typedef Peso Apontador;

bool inicializa (Grafo * g, int nv);

bool verificaVertice (int v, Grafo * g);

bool insereAresta (Grafo * g, int v1, int v2, Peso peso);

Peso obtemPeso(Grafo* g, int i, int j, int maxvert, bool * existe);

Peso pesoAntecessor(Grafo* g , int v1, int antecessor[], bool * existe);

void refazGrafo(Grafo * * aux, int pai[]);

