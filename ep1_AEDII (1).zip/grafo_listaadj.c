#include "grafo_listaadj.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <limits.h>

bool inicializa (Grafo * g, int nv){

    if((nv > MAXNUMVERTICES) || (nv < 0)) return false;

    g->numVertices = nv;
    g->numArestas = 0;

    if (!(g->listaAdj = (Apontador *)calloc(nv + 1, sizeof(Apontador))))
    {
        return false;
    }
    // calloc ja inicializa com zeros. ...
    return true;

}

bool verificaVertice(int v, Grafo * g){
    if(v > g->numVertices || v < 0 ) return false;
    return true;
}

bool insereAresta (Grafo * g, int v1, int v2, Peso peso){
    Apontador p;

    if(!verificaVertice(v1,g) || !verificaVertice(v2, g)) return false;

    if(!(p = (Apontador) calloc (1, sizeof(Aresta)) )) return false;

    p->vdest = v2;
    p -> peso = peso;
    p -> prox = g->listaAdj[v1];
    g->listaAdj[v1] = p;
    g->numArestas ++;

    return true;

}

Peso obtemPeso (Grafo * g, int i, int j, int maxvert, bool * existe){
    Apontador q;
    q = g->listaAdj[j];
    while(q != NULL && q->vdest != maxvert){
        
         q = q->prox;
    
    }

    if(q != NULL) *existe = true;
    if(q == NULL) *existe = false;

    if(q != NULL && q->vdest == maxvert) return q->peso;
}

Peso pesoAntecessor(Grafo * g, int v1, int antecessor[], bool * existe){
    Apontador q;
    q = g->listaAdj[v1];
    while(q != NULL && q->vdest != antecessor[v1]){
        
        q = q->prox;
    
    }
    if(q != NULL) *existe = true;
    if(q == NULL) *existe = false;

    if(q != NULL && q->vdest == antecessor[v1]) return q->peso;
}

void refazGrafo(Grafo * * aux, int pai []){
    int i, j;
    Grafo * g = *aux;

    int V = g->numVertices;
    Apontador q, ant;

    for(i = 0 ; i < V ; i++){

        for(j = 0 ; j < V ; j++){            
        
            q = g->listaAdj[i];
        
            while(q != NULL && q->vdest != j){
                ant = q;
                q = q->prox;
            }

            if(q != NULL && q->vdest == j){    

                if (pai[j] != i && pai[i] != j){
                
                    if(g->listaAdj[i] == q) g->listaAdj[i] = q->prox;
                    else{ant->prox = q->prox;}
                
                    q->prox = NULL;
                    free(q);
                    q = NULL; 
                
                }
            }       
        }
    }
}
