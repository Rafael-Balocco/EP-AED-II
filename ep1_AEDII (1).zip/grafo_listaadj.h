#include <stdbool.h>

#define MAXNUMVERTICES 100
#define AN -1
#define VERTICE_INVALIDO NULL

typedef float Peso;

typedef struct str_aresta { //tudo que está dentro de cada aresta
    int vdest;
    Peso peso;
    struct str_aresta * prox;
}Aresta;

typedef Aresta *Apontador;


typedef struct{
    Apontador *listaAdj;
    int numVertices;
    int numArestas;
} Grafo;

bool inicializa (Grafo * g, int nv);

bool verificaVertice(int v, Grafo * g);

bool insereAresta (Grafo * g, int v1, int v2, Peso peso);

Peso obtemPeso (Grafo * g, int i, int j, int maxvert, bool * existe);

Peso pesoAntecessor(Grafo * g, int v1, int antecessor[], bool * existe);

void refazGrafo(Grafo * * aux, int pai []);



