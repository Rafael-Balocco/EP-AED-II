//#include "grafo_listaadj.h"
#include "grafo_matrizadj.h"

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <limits.h>

int extraiMax(Grafo * g, bool visitado[], float pesof[]){
    int indicemax = -1;
    float pesoMax = AN;

    int i;

    for(i = 0 ; i < g->numVertices ; i++){
        
        if(visitado[i] == false && pesof[i] > pesoMax){    
            pesoMax = pesof[i];
            indicemax = i;
        }

    }
    return indicemax;
}

void MST (Grafo * g){
    int V = g->numVertices;
    bool visitado[V];
    float pesof[V];
    int pai[V];

    int i, j;

    for(i=0; i < V; i++){
        visitado[i] = false;
        pesof[i] = AN;
    }

    pesof[0] = INT_MAX;
    pai[0] = AN; 

    for(i = 0 ; i < V ; i++){
        int indiceMaxVert = extraiMax(g, visitado,pesof);

        visitado [indiceMaxVert] = true;

        bool existe;


        for(j = 0 ; j < V ; j++){
            Peso aux = obtemPeso (g, indiceMaxVert, j, indiceMaxVert, &existe);

            if(existe == true && visitado[j] == false){

                if(aux > pesof[j]){

                    pesof[j] = aux;
                
                    pai[j] = indiceMaxVert;
                
                }
            }

        }
    }
    refazGrafo(&g, pai);
}

void visitaBp(Grafo * g, int v1, int v2, int cor [], bool * achou, Peso * menorAresta, int antecessor[], int * inicial){
    int i, trash;
    cor[v1] = 1;
    bool existe;
    if(v1 != v2){
        for(i = 0 ; i < g->numVertices ; i++){            
            
            trash = i;

            Peso aux = obtemPeso(g, trash, v1, i, &existe);

            //printf("A aresta %d %d existe? %d \n", v1, i, existe);

            if((existe == true) && ( cor[i] == 0)){
                antecessor[i] = v1; 
                visitaBp(g, i, v2, cor, achou, menorAresta, antecessor, inicial);
            }
            if(*achou == true) break;
        }
    } 
    if(v1 == v2){
        *achou = true;
        Peso ant = pesoAntecessor(g, v1, antecessor, &existe);
        *menorAresta = ant;
        //printf("%d e %d e agora tem peso %.1f\n", v1, v2, ant);
    }
    if(*achou == true && *inicial != v1){
        Peso ant = pesoAntecessor(g, v1, antecessor, &existe);
        if(*menorAresta > ant){
            *menorAresta =ant;
        }
    }
    return;
}        

Peso buscaProf(Grafo * g, int v1, int v2){
    int i;
    int cor [g->numVertices]; //0 = branco, 1 = ciza, 2 = preto
    int antecessor[g->numVertices];

    for(i = 0 ; i < g->numVertices ; i++){
        cor[i] = 0;
        antecessor [i] = -1;
    }

    bool achou = false;

    Peso menorAresta;

    int incial = v1;

    visitaBp(g, v1, v2, cor, &achou, &menorAresta, antecessor, &incial);


    //printf("%.1f \n", menorAresta);

    Peso resposta;

    if(menorAresta >= 4.5) resposta = 4.5;

    if(menorAresta < 4.5 && menorAresta >= 4) resposta = 4;

    if(menorAresta < 4 && menorAresta >= 3.5) resposta = 3.5;

    if(menorAresta < 3.5 && menorAresta >= 3) resposta = 3;

    if(menorAresta < 3 && menorAresta >= 2.5) resposta = 2.5;


    return (resposta);

}

int main (int argc, char const *argv[]){

    FILE * arquivo = fopen(argv[1], "r");

    int i; int centros; int rotas; int consultas;

    fscanf(arquivo, "%d %d %d\n", &centros, &rotas, &consultas);    

    int v1, v2;
    
    Peso pesoinsere;

    Grafo g;

    inicializa(&g, centros);

    for(i = 0 ; i < rotas ; i++){
        fscanf(arquivo, "%d %d %f \n", &v1, &v2, &pesoinsere);
        
        insereAresta(&g, v1, v2, pesoinsere);
        insereAresta(&g, v2, v1, pesoinsere);
    }

    MST(&g);

    FILE * file;

    file = fopen("saida.txt", "w");

    Peso tamCaminhao [consultas]; 
    
    for(i = 0; i < consultas ; i++){

        fscanf(arquivo, "%d %d \n", &v1, &v2);

        //printf("Estamos procurando nos vertices %d %d\n", v1, v2);

        tamCaminhao[i] = buscaProf(&g, v1, v2);

    }

    for (i = 0; i < consultas ; i++) {
        fprintf(file, "%.1f\n", tamCaminhao[i]);
    }
    
    fclose(file);
    
    return -1;
}