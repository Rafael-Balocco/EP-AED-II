#include "grafo_matrizadj.h"
#include <stdio.h>
#include <stdbool.h>
#include <limits.h>

bool inicializa (Grafo * g, int nv){ // vai recebero tanto de grafos criados
    if ((nv > MAXNUMVERTICES) || (nv < 0) ) return false;

    g -> numVertices = nv;
    g-> numArestas =0;

    int i , j;

    for(i = 0 ; i < nv ; i++){
        for(j=0 ; j< nv ; j++){
            g->mat[i][j] = AN;
        }
    }

    return true;
}

bool verificaVertice (int v, Grafo * g){
    if( v > g->numVertices || v < 0) return false;
    return true;
}

bool insereAresta (Grafo * g, int v1, int v2, Peso peso){
    if(!verificaVertice(v1, g) || !verificaVertice(v2, g)) return false;

    g->mat[v1][v2] = peso; 
    g->numArestas ++;
    return true;
}

Peso obtemPeso(Grafo * g, int i, int j, int maxvert, bool * existe){
    if(g->mat[i][j] != AN) *existe = true;
    else *existe = false;
    
    return g->mat[i][j];
}

Peso pesoAntecessor(Grafo * g, int v1, int antecessor[], bool * existe){
    if(g->mat[v1][antecessor[v1]] != AN) *existe = true;
    else *existe = false;
    
    return g->mat[v1][antecessor[v1]];
}

void refazGrafo (Grafo * * aux, int pai []){
    int i,j;
    Grafo * g = *aux;
    int V = g->numVertices;

    for(i = 0 ; i < V ; i++){ //limpando o grafo.
        for(j = 0 ; j < V ; j++){
            if(g->mat[i][j] != -1){
                if (pai[j] != i && pai[i] != j){
                    g->mat[i][j] = AN;
                }
            }    
        }
    }
}    

